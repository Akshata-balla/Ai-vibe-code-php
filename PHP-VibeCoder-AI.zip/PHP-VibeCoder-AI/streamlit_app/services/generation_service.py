import os
from pathlib import Path

import requests
from dotenv import load_dotenv


ENV_FILE = (
    Path(__file__)
    .resolve()
    .parent
    .parent
    / ".env"
)

load_dotenv(ENV_FILE)

MODEL_API_URL = os.getenv(
    "MODEL_API_URL",
    ""
).rstrip("/")


def generate_php(user_request, rag_context):

    if not MODEL_API_URL:
        raise RuntimeError(
            "MODEL_API_URL is not configured."
        )

    response = requests.post(
        f"{MODEL_API_URL}/generate",
        json={
            "user_request": user_request,
            "rag_context": rag_context
        },
        timeout=180
    )

    response.raise_for_status()

    result = response.json()

    if not result.get("success"):
        raise RuntimeError(
            "PHP generation failed."
        )

    return result["code"]
def debug_php(
    php_code,
    failures,
    rag_context
):

    if not MODEL_API_URL:
        raise RuntimeError(
            "MODEL_API_URL is not configured."
        )

    response = requests.post(
        f"{MODEL_API_URL}/debug",
        json={
            "php_code": php_code,
            "failures": failures,
            "rag_context": rag_context
        },
        timeout=180
    )

    response.raise_for_status()

    result = response.json()

    if not result.get("success"):
        raise RuntimeError(
            "Model API debugging failed."
        )

    return result["code"]