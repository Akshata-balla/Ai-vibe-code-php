import subprocess
from pathlib import Path


PROJECT_ROOT = (
    Path(__file__)
    .resolve()
    .parent
    .parent
    .parent
)

CI_APP = PROJECT_ROOT / "ci_app"

PHP_RUNNER = (
    CI_APP
    / "tools"
    / "php_runner.py"
)


def run_php_pipeline():
    try:
        result = subprocess.run(
            [
                "python",
                str(PHP_RUNNER)
            ],
            capture_output=True,
            text=True,
            cwd=PROJECT_ROOT
        )

        output = (
            result.stdout
            + "\n"
            + result.stderr
        ).strip()

        return {
            "success": (
                result.returncode == 0
                and "CODE READY FOR DELIVERY" in output
            ),
            "returncode": result.returncode,
            "output": output
        }

    except Exception as exc:
        return {
            "success": False,
            "returncode": -1,
            "output": str(exc)
        }


def save_generated_php(code: str):
    php_file = (
        CI_APP
        / "generated_projects"
        / "test.php"
    )

    php_file.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    php_file.write_text(
        code,
        encoding="utf-8"
    )

    return str(php_file)