from pathlib import Path

import chromadb
from sentence_transformers import SentenceTransformer


PROJECT_ROOT = (
    Path(__file__)
    .resolve()
    .parent
    .parent
    .parent
)

CI_APP = PROJECT_ROOT / "ci_app"

CHROMA_DIR = CI_APP / "chroma_db"

MODEL_NAME = "all-MiniLM-L6-v2"
COLLECTION_NAME = "php_vibecoder_knowledge"


embedding_model = SentenceTransformer(MODEL_NAME)


def retrieve_knowledge(user_request, top_k=2):

    client = chromadb.PersistentClient(
        path=str(CHROMA_DIR)
    )

    collection = client.get_collection(
        name=COLLECTION_NAME
    )

    query_embedding = embedding_model.encode(
        user_request
    ).tolist()

    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k
    )

    retrieved = []

    for i in range(
        len(results["documents"][0])
    ):

        retrieved.append(
            {
                "source": (
                    results["metadatas"][0][i]["source"]
                ),
                "document": (
                    results["documents"][0][i]
                ),
                "distance": (
                    results["distances"][0][i]
                )
            }
        )

    return retrieved