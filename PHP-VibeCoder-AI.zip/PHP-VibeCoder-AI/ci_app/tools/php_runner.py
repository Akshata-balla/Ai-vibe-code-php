import subprocess
import sys
from pathlib import Path

from debug_agent import analyze_failure


# ---------------------------------------------------------
# PATHS
# ---------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent

PHP_FILE = (
    BASE_DIR
    / "generated_projects"
    / "test.php"
)

TEST_FILE = (
    BASE_DIR
    / "generated_projects"
    / "tests"
    / "registration_test.php"
)

GAN_TEST_FILE = (
    BASE_DIR
    / "generated_projects"
    / "tests"
    / "gan_registration_test.php"
)


# "registration" = full tests + CTGAN, "generic" = syntax + execution only
MODE = sys.argv[1] if len(sys.argv) > 1 else "registration"


# ---------------------------------------------------------
# COMMAND RUNNER
# ---------------------------------------------------------

def run_command(command):

    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        cwd=BASE_DIR
    )

    return {
        "success": result.returncode == 0,
        "returncode": result.returncode,
        "stdout": result.stdout.strip(),
        "stderr": result.stderr.strip()
    }


# ---------------------------------------------------------
# PHP SYNTAX CHECK
# ---------------------------------------------------------

def syntax_check():

    return run_command([
        "php",
        "-l",
        str(PHP_FILE)
    ])


# ---------------------------------------------------------
# PHP EXECUTION
# ---------------------------------------------------------

def execute_php():

    return run_command([
        "php",
        str(PHP_FILE)
    ])


# ---------------------------------------------------------
# FUNCTIONAL TESTS
# ---------------------------------------------------------

def run_tests():

    return run_command([
        "php",
        str(TEST_FILE)
    ])


# ---------------------------------------------------------
# CTGAN SYNTHETIC TESTS
# ---------------------------------------------------------

def run_gan_tests():

    return run_command([
        "php",
        str(GAN_TEST_FILE)
    ])


# ---------------------------------------------------------
# FAILURE ANALYSIS
# ---------------------------------------------------------

def analyze_tests(test_result):

    output = (
        test_result["stdout"]
        + "\n"
        + test_result["stderr"]
    )

    failures = []

    for line in output.splitlines():

        if (
            line.startswith("FAIL:")
            or line.startswith("TEST ERROR:")
            or line.startswith("GAN TEST ERROR:")
        ):
            failures.append(line)

    return failures


# ---------------------------------------------------------
# MAIN PIPELINE
# ---------------------------------------------------------

def main():

    print("=" * 60)
    print("PHP VIBECODER - AUTOMATED TEST PIPELINE")
    print("=" * 60)

    print("\nTesting:")
    print(PHP_FILE)


    # =====================================================
    # 1. SYNTAX CHECK
    # =====================================================

    print("\n[1] SYNTAX CHECK")

    syntax = syntax_check()

    print(syntax)

    if not syntax["success"]:

        print("STATUS: FAILED")
        print("PHP syntax error detected.")

        return

    print("STATUS: PASSED")


    # =====================================================
    # 2. PHP EXECUTION
    # =====================================================

    print("\n[2] PHP EXECUTION")

    execution = execute_php()

    print(execution)

    if not execution["success"]:

        print("STATUS: FAILED")
        print("PHP runtime error detected.")

        return

    print("STATUS: PASSED")


    # =====================================================
    # 3. FUNCTIONAL TESTS
    # =====================================================

    # ---------------------------------------------
    # GENERIC MODE: registration-specific tests skip
    # ---------------------------------------------

    if MODE == "generic":

        print("\n[3] FUNCTIONAL / CTGAN TESTS")
        print(
            "SKIPPED: no dedicated test suite for this "
            "requirement type (generic mode)."
        )
        print("STATUS: PASSED")

        print("\nSyntax check and PHP execution passed.")
        print("\n>>> CODE READY FOR DELIVERY <<<")

        return

    print("\n[3] FUNCTIONAL TESTS")

    tests = run_tests()

    if tests["stdout"]:
        print(tests["stdout"])

    if tests["stderr"]:
        print(tests["stderr"])

    failures = analyze_tests(tests)

    if not tests["success"]:

        print("STATUS: FAILED")
        print("Functional test process failed.")

        return

    if failures:

        print("\nSTATUS: FAILED")

        print("\nDetected failures:")

        for failure in failures:
            print("-", failure)

        # ---------------------------------------------
        # DEBUG AGENT
        # ---------------------------------------------

        print("\n[4] DEBUG AGENT")

        debug_result = analyze_failure(
            failures
        )

        print(
            "\nDebug prompt generated successfully."
        )

        print("\n" + "=" * 60)

        print(
            debug_result["debug_prompt"]
        )

        print("=" * 60)

        return

    print("\nSTATUS: PASSED")


    # =====================================================
    # 4. CTGAN SYNTHETIC TESTS
    # =====================================================

    print("\n[4] CTGAN SYNTHETIC TESTS")

    gan_tests = run_gan_tests()

    if gan_tests["stdout"]:
        print(gan_tests["stdout"])

    if gan_tests["stderr"]:
        print(gan_tests["stderr"])

    if not gan_tests["success"]:

        print("\nSTATUS: FAILED")
        print(
            "CTGAN synthetic testing failed."
        )

        return

    print("\nSTATUS: PASSED")


    # =====================================================
    # 5. FINAL TEST ANALYSIS
    # =====================================================

    print("\n[5] TEST ANALYSIS")

    print("STATUS: PASSED")

    print(
        "\nAll automated tests passed."
    )

    print(
        "\n>>> CODE READY FOR DELIVERY <<<"
    )


# ---------------------------------------------------------
# START PROGRAM
# ---------------------------------------------------------

if __name__ == "__main__":
    main()