from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

PHP_FILE = BASE_DIR / "generated_projects" / "test.php"


def read_php_code():
    """Read the PHP file that failed testing."""
    return PHP_FILE.read_text(encoding="utf-8")


def build_debug_prompt(failures):
    """Build a debugging prompt for the PHP LLM."""

    php_code = read_php_code()

    failure_text = "\n".join(
        f"- {failure}" for failure in failures
    )

    prompt = f"""
You are PHP VibeCoder Debug Agent.

The following PHP code failed automated functional tests.

FAILED TESTS:
{failure_text}

CURRENT PHP CODE:

{php_code}

Analyze the failures and correct the PHP code.

Requirements:
- Fix the actual cause of the failed tests.
- Preserve functionality that already works.
- Follow secure PHP 8.x practices.
- Never store passwords as plain text.
- Use password_hash() for password storage.
- Return only the corrected PHP code.
"""

    return prompt.strip()


def analyze_failure(failures):
    """Create debugging information for the LLM."""

    return {
        "failed": True,
        "failures": failures,
        "php_file": str(PHP_FILE),
        "debug_prompt": build_debug_prompt(failures),
    }


if __name__ == "__main__":

    test_failures = [
        "FAIL: Password stored as plain text.",
        "FAIL: Password hash verification failed.",
    ]

    result = analyze_failure(test_failures)

    print("=" * 60)
    print("PHP VIBECODER DEBUG AGENT")
    print("=" * 60)

    print("\nDetected Failures:")

    for failure in result["failures"]:
        print("-", failure)

    print("\nGenerated Debug Prompt:\n")

    print(result["debug_prompt"])