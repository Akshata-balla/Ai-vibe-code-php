<?php

function registerCustomer(PDO $pdo, string $name, string $email, string $password): bool
{
    // Validate email address
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    // Hash the password using password_hash()
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert the new customer into the database
    $stmt = $pdo->prepare("INSERT INTO customers (name, email, password_hash) VALUES (?, ?, ?)");
    $stmt->execute([$name, $email, $hashedPassword]);

    return true;
}
?>