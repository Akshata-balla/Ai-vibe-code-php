<?php

require_once __DIR__ . '/../test.php';

function createTestDatabase(): PDO
{
    $pdo = new PDO('sqlite::memory:');

    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

    $pdo->exec("
        CREATE TABLE customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL
        )
    ");

    return $pdo;
}


function testInvalidEmail(): void
{
    $pdo = createTestDatabase();

    $result = registerCustomer(
        $pdo,
        'Test User',
        'invalid-email',
        'SecurePassword123!'
    );

    if ($result === false) {
        echo "PASS: Invalid email rejected." . PHP_EOL;
    } else {
        echo "FAIL: Invalid email accepted." . PHP_EOL;
    }
}


function testValidRegistration(): void
{
    $pdo = createTestDatabase();

    $plainPassword = 'SecurePassword123!';

    $result = registerCustomer(
        $pdo,
        'Test User',
        'test@example.com',
        $plainPassword
    );

    if ($result !== true) {
        echo "FAIL: Registration failed." . PHP_EOL;
        return;
    }

    $stmt = $pdo->query(
        "SELECT name, email, password_hash
         FROM customers
         WHERE email = 'test@example.com'"
    );

    $customer = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$customer) {
        echo "FAIL: Customer was not inserted." . PHP_EOL;
        return;
    }

    echo "PASS: Customer inserted." . PHP_EOL;

    if ($customer['password_hash'] !== $plainPassword) {
        echo "PASS: Password was not stored as plain text." . PHP_EOL;
    } else {
        echo "FAIL: Password stored as plain text." . PHP_EOL;
    }

    if (
        password_verify(
            $plainPassword,
            $customer['password_hash']
        )
    ) {
        echo "PASS: Password hash verified." . PHP_EOL;
    } else {
        echo "FAIL: Password hash verification failed." . PHP_EOL;
    }
}


testInvalidEmail();
testValidRegistration();