<?php

require_once __DIR__ . '/../test.php';

function createGanTestDatabase(): PDO
{
    $pdo = new PDO('sqlite::memory:');

    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

    $pdo->exec("
        CREATE TABLE customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL
        )
    ");

    return $pdo;
}


$csvFile = __DIR__ . '/../synthetic_customer_test_data.csv';

if (!file_exists($csvFile)) {
    echo "GAN TEST ERROR: CSV file not found." . PHP_EOL;
    exit(1);
}

$handle = fopen($csvFile, 'r');

$headers = fgetcsv($handle);

$total = 0;
$passed = 0;
$failed = 0;

$pdo = createGanTestDatabase();

echo "GAN SYNTHETIC TESTING" . PHP_EOL;
echo str_repeat("-", 40) . PHP_EOL;

while (($row = fgetcsv($handle)) !== false) {

    $record = array_combine(
        $headers,
        $row
    );

    $total++;

    $nameLength = max(
        3,
        (int)$record['name_length']
    );

    $passwordLength = max(
        8,
        (int)$record['password_length']
    );

    $name = substr(
        str_repeat("TestUser", 5),
        0,
        $nameLength
    );

    $email = "user{$total}@example.com";

    $password = substr(
        str_repeat("SecurePass123!", 5),
        0,
        $passwordLength
    );

    try {

        $result = registerCustomer(
            $pdo,
            $name,
            $email,
            $password
        );

        if ($result === true) {

            $stmt = $pdo->prepare(
                "SELECT password_hash
                 FROM customers
                 WHERE email = ?"
            );

            $stmt->execute([$email]);

            $customer = $stmt->fetch(
                PDO::FETCH_ASSOC
            );

            if (
                $customer &&
                password_verify(
                    $password,
                    $customer['password_hash']
                )
            ) {

                echo "PASS: Record {$total}" . PHP_EOL;
                $passed++;

            } else {

                echo "FAIL: Record {$total} password verification failed."
                    . PHP_EOL;

                $failed++;
            }

        } else {

            echo "FAIL: Record {$total} registration rejected."
                . PHP_EOL;

            $failed++;
        }

    } catch (Throwable $e) {

        echo "FAIL: Record {$total} - "
            . $e->getMessage()
            . PHP_EOL;

        $failed++;
    }
}

fclose($handle);

echo str_repeat("-", 40) . PHP_EOL;

echo "Total tests: {$total}" . PHP_EOL;
echo "Passed: {$passed}" . PHP_EOL;
echo "Failed: {$failed}" . PHP_EOL;

if ($failed === 0) {

    echo "GAN TEST STATUS: PASSED" . PHP_EOL;
    exit(0);

} else {

    echo "GAN TEST STATUS: FAILED" . PHP_EOL;
    exit(1);
}