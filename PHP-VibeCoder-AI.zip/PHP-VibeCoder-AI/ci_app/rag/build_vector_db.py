from pathlib import Path

import chromadb
from sentence_transformers import SentenceTransformer


BASE_DIR = Path(__file__).resolve().parent.parent
KNOWLEDGE_DIR = BASE_DIR / "knowledge_base"
CHROMA_DIR = BASE_DIR / "chroma_db"

MODEL_NAME = "all-MiniLM-L6-v2"


def load_documents():
    documents = []

    for file_path in KNOWLEDGE_DIR.rglob("*.txt"):
        text = file_path.read_text(encoding="utf-8")

        documents.append(
            {
                "id": str(file_path.relative_to(KNOWLEDGE_DIR)),
                "text": text,
                "source": str(file_path.relative_to(BASE_DIR)),
            }
        )

    return documents


def build_vector_database():
    print("Loading embedding model...")
    model = SentenceTransformer(MODEL_NAME)

    documents = load_documents()

    print(f"Documents found: {len(documents)}")

    client = chromadb.PersistentClient(
        path=str(CHROMA_DIR)
    )

    collection = client.get_or_create_collection(
        name="php_vibecoder_knowledge"
    )

    for document in documents:
        embedding = model.encode(
            document["text"]
        ).tolist()

        collection.upsert(
            ids=[document["id"]],
            documents=[document["text"]],
            embeddings=[embedding],
            metadatas=[
                {
                    "source": document["source"]
                }
            ],
        )

        print("Added:", document["id"])

    print("\nVector database created successfully.")
    print("Stored in:", CHROMA_DIR)


if __name__ == "__main__":
    build_vector_database()