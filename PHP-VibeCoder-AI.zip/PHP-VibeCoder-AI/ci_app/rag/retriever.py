from pathlib import Path

import chromadb
from sentence_transformers import SentenceTransformer


BASE_DIR = Path(__file__).resolve().parent.parent
CHROMA_DIR = BASE_DIR / "chroma_db"

MODEL_NAME = "all-MiniLM-L6-v2"
COLLECTION_NAME = "php_vibecoder_knowledge"


def retrieve_knowledge(query: str, top_k: int = 2):
    model = SentenceTransformer(MODEL_NAME)

    client = chromadb.PersistentClient(
        path=str(CHROMA_DIR)
    )

    collection = client.get_collection(
        name=COLLECTION_NAME
    )

    query_embedding = model.encode(query).tolist()

    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k
    )

    retrieved = []

    for i in range(len(results["documents"][0])):
        retrieved.append(
            {
                "document": results["documents"][0][i],
                "source": results["metadatas"][0][i]["source"],
                "distance": results["distances"][0][i]
            }
        )

    return retrieved


if __name__ == "__main__":

    question = "How should passwords be stored securely in PHP?"

    print("Question:")
    print(question)

    results = retrieve_knowledge(
        query=question,
        top_k=2
    )

    print("\nRetrieved Knowledge:\n")

    for index, result in enumerate(results, start=1):

        print(f"Result {index}")
        print("Source:", result["source"])
        print("Distance:", result["distance"])
        print()
        print(result["document"])
        print("-" * 60)