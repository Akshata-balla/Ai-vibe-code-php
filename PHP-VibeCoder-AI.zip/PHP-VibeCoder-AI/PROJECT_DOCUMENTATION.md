# PHP VibeCoder AI

> **GenAI + RAG + GAN-Inspired Intelligent PHP Development Pipeline**

PHP VibeCoder AI is a AI-assisted software
development system that converts natural-language requirements into
PHP code and then executes, tests, debugs, retests, and validates the
generated program before delivery.

The project combines a fine-tuned coding LLM, Retrieval-Augmented
Generation (RAG), real PHP execution, deterministic validation, an AI
Debug Agent, and CTGAN-based synthetic testing.

**Core workflow**

`Requirement → RAG → AI Generation → PHP Execution → Testing → AI Debugging → Retesting → Synthetic Validation → Delivery`

------------------------------------------------------------------------

## Table of Contents

-   [1. Problem Statement](#1-problem-statement)
-   [2. Objectives](#2-objectives)
-   [3. System Architecture](#3-system-architecture)
-   [4. End-to-End Workflow](#4-end-to-end-workflow)
-   [5. Technology Stack](#5-technology-stack)
-   [6. Model Development](#6-model-development)
-   [7. LoRA Fine-Tuning](#7-lora-fine-tuning)
-   [8. Hugging Face Model Storage](#8-hugging-face-model-storage)
-   [9. RAG and ChromaDB](#9-rag-and-chromadb)
-   [10. Kaggle GPU Inference](#10-kaggle-gpu-inference)
-   [11. FastAPI Model Service](#11-fastapi-model-service)
-   [12. ngrok Connection](#12-ngrok-connection)
-   [13. Streamlit Application](#13-streamlit-application)
-   [14. PHP Execution and Testing](#14-php-execution-and-testing)
-   [15. AI Debug Agent](#15-ai-debug-agent)
-   [16. Controlled Security Failure
    Demo](#16-controlled-security-failure-demo)
-   [17. CTGAN Synthetic Testing](#17-ctgan-synthetic-testing)
-   [18. Hybrid AI Architecture](#18-hybrid-ai-architecture)
-   [19. Docker Containerization](#19-docker-containerization)
-   [20. Project Structure](#20-project-structure)
-   [21. Installation and Setup](#21-installation-and-setup)
-   [22. Running the Application](#22-running-the-application)
-   [23. Example Demonstration](#23-example-demonstration)
-   [24. Security Practices](#24-security-practices)
-   [25. Results](#25-results)
-   [26. Limitations](#26-limitations)
-   [27. Future Improvements](#27-future-improvements)
-   [28. Project Contribution](#28-project-contribution)
-   [29. Conclusion](#29-conclusion)

------------------------------------------------------------------------

## 1. Problem Statement

Large Language Models can generate source code from natural-language
requirements, but generated code may contain syntax errors, runtime
problems, insecure database operations, or security vulnerabilities.

Therefore, generating code alone is not enough.

PHP VibeCoder AI extends LLM-based code generation with:

-   domain-specific knowledge retrieval,
-   real PHP execution,
-   syntax and functional testing,
-   synthetic-data testing,
-   automatic failure detection,
-   AI-assisted debugging,
-   automatic retesting,
-   and final delivery validation.

The project demonstrates how Generative AI can be combined with
conventional software-engineering validation instead of blindly trusting
generated code.

------------------------------------------------------------------------

## 2. Objectives

The main objectives are to:

1.  Accept PHP application requirements written in natural language.
2.  Retrieve relevant PHP, MySQL, CodeIgniter, and secure-coding
    knowledge.
3.  Generate PHP using a task-adapted coding LLM.
4.  Save and execute the generated PHP in a real PHP runtime.
5.  Perform syntax, execution, and functional validation.
6.  Generate synthetic structured test records using CTGAN.
7.  Detect failed tests automatically.
8.  Send failed code and failure information to an AI Debug Agent.
9.  Generate corrected PHP.
10. Automatically retest the correction.
11. Mark code ready for delivery only after successful validation.

------------------------------------------------------------------------

## 3. System Architecture

``` mermaid
flowchart TD
    A["User"] --> B["Streamlit UI"]
    B --> C["Natural-Language Requirement"]
    C --> D["RAG Retrieval - ChromaDB"]
    D --> E["Fine-Tuned Qwen2.5-Coder + LoRA"]
    E --> F["PHP Code Generation"]
    F --> G["Save Generated PHP"]
    G --> H["PHP Syntax / Runtime / Functional Tests"]
    H --> I{"Tests Passed?"}
    I -->|No| K["AI Debug Agent"]
    K --> L["Generate Corrected PHP"]
    L --> M["Save Corrected PHP"]
    M --> N["Automatic Retesting"]
    N --> O{"Retest Passed?"}
    O -->|No| K
    O -->|Yes| J["CTGAN Synthetic Testing"]
    I -->|Yes| J
    J --> P{"Synthetic Tests Passed?"}
    P -->|No| K
    P -->|Yes| Q["CODE READY FOR DELIVERY"]
```

### Deployment / Integration View

``` text
Google Colab
  │
  └── LoRA fine-tuning
          │
          ▼
Hugging Face
  │
  └── Merged Qwen model storage
          │
          ▼
Kaggle GPU
  │
  ├── Load model
  ├── /generate
  └── /debug
          │
       FastAPI
          │
        ngrok
          │
          ▼
Local Streamlit Application (VS Code)
  │
  ├── RAG / ChromaDB
  ├── PHP file generation
  ├── PHP runtime
  ├── Functional testing
  ├── Debug loop
  └── CTGAN testing
```

------------------------------------------------------------------------

## 4. End-to-End Workflow

``` text
User Requirement
       ↓
Streamlit Interface
       ↓
RAG Retrieval
       ↓
Relevant Knowledge Context
       ↓
Qwen2.5-Coder + LoRA
       ↓
PHP Generation
       ↓
Save PHP File
       ↓
PHP Syntax Check
       ↓
Runtime Execution
       ↓
Functional Tests
       ↓
Tests Passed?
   ┌───────┴───────┐
   │               │
  YES              NO
   │               │
   │          AI Debug Agent
   │               ↓
   │          Corrected PHP
   │               ↓
   │             Retest
   │               │
   └───────────────┘
           ↓
   CTGAN Synthetic Tests
           ↓
   CODE READY FOR DELIVERY
```

------------------------------------------------------------------------

## 5. Technology Stack

  Component                   Technology
  --------------------------- --------------------
  Main development language   Python
  Generated/target language   PHP 8.x
  Base coding model           Qwen2.5-Coder-1.5B
  Model adaptation            LoRA / PEFT
  Model repository            Hugging Face
  Retrieval architecture      RAG
  Vector database             ChromaDB
  Synthetic data              CTGAN
  Model API                   FastAPI
  User interface              Streamlit
  GPU inference               Kaggle GPU
  API tunnel                  ngrok
  PHP execution               PHP CLI
  Containerization            Docker
  Version control             Git / GitHub
  Local development           VS Code

------------------------------------------------------------------------

## 6. Model Development

The project uses **Qwen2.5-Coder-1.5B** as the pretrained coding model.

This approach is more practical for a proof-of-concept because training
a large language model Like GAN,that tried from scratch requires substantially more data and
computational resources.

The model-development flow was:

``` text
Pretrained Qwen2.5-Coder
          ↓
PHP-oriented training examples
          ↓
LoRA / PEFT fine-tuning
          ↓
Merge adapter with base model
          ↓
Store merged model on Hugging Face

------------------------------------------------------------------------

## 7. LoRA Fine-Tuning

**LoRA (Low-Rank Adaptation)** was used as a parameter-efficient
fine-tuning technique.

The training examples focused on secure PHP development patterns such
as:

-   secure password hashing,
-   email validation,
-   PDO usage,
-   prepared SQL statements,
-   database insertion,
-   clean PHP functions,
-   secure coding practices.

Example:

``` php
$hashedPassword = password_hash(
    $password,
    PASSWORD_DEFAULT
);
```

Conceptually:

``` text
Pretrained Qwen
      +
LoRA task adaptation
      ↓
PHP-oriented coding model
```

LoRA is not mandatory for the architecture to operate. A base model can
also be combined with RAG. In this project, LoRA provides an additional
task-specific adaptation layer.

### LoRA vs. RAG

-   **LoRA** adapts model behavior through training.
-   **RAG** supplies relevant external knowledge at inference time.

A simple analogy is:

``` text
Qwen = trained student
LoRA = specialized coaching before the exam
RAG  = relevant reference notes during the exam
```

------------------------------------------------------------------------

## 8. Hugging Face Model Storage

After fine-tuning, the LoRA adapter was merged with the base model and
the resulting model was stored on Hugging Face.

**Model repository**

`sonamrata/php-vibecoder-qwen-merged`

This separates training from inference: the final model can be loaded in
another environment without repeating the fine-tuning process.

``` text
Google Colab
    ↓
LoRA Fine-Tuning
    ↓
Merge Adapter + Base Model
    ↓
Hugging Face
    ↓
Kaggle GPU Inference
```

> Access tokens and credentials must never be committed to this
> repository.

------------------------------------------------------------------------

## 9. RAG and ChromaDB

A custom knowledge base provides domain-specific context to the model.

Knowledge areas include:

-   PHP,
-   MySQL,
-   CodeIgniter,
-   coding standards and security guidance.

Example structure:

``` text
knowledge_base/
├── php/
│   └── php_basics.txt
├── mysql/
│   └── mysql_basics.txt
├── codeigniter/
│   └── codeigniter_basics.txt
└── coding_standards/
```

The knowledge is indexed in **ChromaDB**.

When a requirement is submitted, the RAG component searches for relevant
content and provides that context to the generation model.

``` text
User Requirement
      ↓
Semantic Retrieval
      ↓
Relevant PHP / MySQL Knowledge
      ↓
Prompt Context
      ↓
Qwen
      ↓
Generated PHP
```

This allows model generation to be grounded in project-relevant
technical knowledge.

------------------------------------------------------------------------

## 10. Kaggle GPU Inference

The final model is run on a GPU-backed Kaggle environment rather than
relying only on the local computer for inference.

The prototype was successfully run with CUDA-enabled Tesla T4 GPU
resources.

``` text
Hugging Face
      ↓
Merged Qwen Model
      ↓
Kaggle GPU
      ↓
Model Inference
```

The Kaggle notebook loads the tokenizer and model from the stored model
repository and exposes model functionality through FastAPI.

------------------------------------------------------------------------

## 11. FastAPI Model Service

FastAPI provides the interface between the model and the Streamlit
application.

### Health Check

``` http
GET /health
```

Example response:

``` json
{
  "status": "ok",
  "model": "PHP VibeCoder Qwen"
}
```

### Code Generation

``` http
POST /generate
```

The endpoint receives the application requirement and relevant RAG
context and returns generated PHP.

### AI Debugging

``` http
POST /debug
```

The debug endpoint receives information such as:

-   current PHP code,
-   failed test information,
-   relevant RAG context.

The Qwen-based Debug Agent then generates corrected PHP.

------------------------------------------------------------------------

## 12. ngrok Connection

The Streamlit application runs on the local Windows environment while
the inference API runs in Kaggle.

**ngrok** is used as a temporary tunnel between these environments.

``` text
Kaggle GPU
    ↓
FastAPI
    ↓
ngrok
    ↓
Temporary Public API URL
    ↓
Local Streamlit
```

The active API URL is stored locally in:

``` text
streamlit_app/.env
```

Example configuration:

``` env
MODEL_API_URL=https://your-current-ngrok-url
```

The actual `.env` file is intentionally excluded from Git.

> Free ngrok URLs can change between sessions. If Kaggle/ngrok is
> restarted, update `MODEL_API_URL` before starting Streamlit again.

------------------------------------------------------------------------

## 13. Streamlit Application

Streamlit provides the main user interface and orchestrates the
end-to-end workflow.

The user can enter a requirement such as:

``` text
Create a secure customer registration system with login,
MySQL database and admin dashboard.
```

The application then:

1.  retrieves RAG context,
2.  calls the model generation API,
3.  receives PHP,
4.  saves the generated PHP,
5.  executes the testing pipeline,
6.  detects failures,
7.  calls the Debug Agent when necessary,
8.  saves corrected PHP,
9.  automatically retests it,
10. performs synthetic testing,
11. reports final delivery status.

------------------------------------------------------------------------

## 14. PHP Execution and Testing

A key part of this project is that generated code is **not only
displayed**.

It is written to an actual PHP file and evaluated through the PHP
runtime.

Generated code is stored in:

``` text
ci_app/generated_projects/test.php
```

The testing pipeline includes multiple validation stages.

### 14.1 Syntax Validation

The PHP interpreter checks whether the generated source has valid PHP
syntax.

### 14.2 Runtime Execution

The program is executed to identify runtime failures.

### 14.3 Functional Testing

The prototype tests important registration requirements, including:

``` text
PASS: Invalid email rejected
PASS: Customer inserted
PASS: Password not stored as plain text
PASS: Password hash verified
```

A typical generated function follows a contract similar to:

``` php
function registerCustomer(
    PDO $pdo,
    string $name,
    string $email,
    string $password
): bool
{
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    $hashedPassword = password_hash(
        $password,
        PASSWORD_DEFAULT
    );

    $stmt = $pdo->prepare(
        "INSERT INTO customers (name, email, password_hash)
         VALUES (?, ?, ?)"
    );

    $stmt->execute([
        $name,
        $email,
        $hashedPassword
    ]);

    return true;
}
```

The prototype uses PDO-oriented generation to align generated database
code with its functional test harness.

------------------------------------------------------------------------

## 15. AI Debug Agent

If the generated PHP fails validation, the system does not immediately
mark it as complete.

Instead, failure information is sent to the AI Debug Agent.

``` text
Failed Test
    ↓
Failure Details + Current PHP + RAG Context
    ↓
Qwen Debug Agent
    ↓
Corrected PHP
    ↓
Save Correction
    ↓
Automatic Retest
```

An important design principle is:

> **The system does not assume that an AI correction is correct. The
> corrected program must pass the tests again before delivery.**

This creates an iterative:

`Generate → Test → Debug → Retest`

workflow.

------------------------------------------------------------------------

## 16. Controlled Security Failure Demo

A deterministic controlled-failure option was added to demonstrate the
debugging loop reliably.

For demonstration only, secure password hashing can intentionally be
replaced.

Secure version:

``` php
$hashedPassword = password_hash(
    $password,
    PASSWORD_DEFAULT
);
```

Controlled insecure version:

``` php
$hashedPassword = $password;
```

This simulates plain-text password storage.

The functional test then detects failures such as:

``` text
FAIL: Password stored as plain text.
FAIL: Password hash verification failed.
```

The failed PHP and test information are passed to the Qwen Debug Agent.

The Debug Agent generates a corrected version using secure hashing,
after which the application automatically retests the code.

Successful completion produces:

``` text
Debug successful.
Corrected code passed all tests.

CODE READY FOR DELIVERY
```

The controlled defect is **only a demonstration mechanism**. It is not
part of normal secure code generation.

------------------------------------------------------------------------

## 17. CTGAN Synthetic Testing

The GAN-inspired component is implemented in the testing stage using
**CTGAN**.

CTGAN generates synthetic structured customer data that can be used to
exercise the generated functionality across multiple artificial records.

Example:

``` text
CTGAN SYNTHETIC TESTING

Total Records: 20
Passed: 20
Failed: 0
```

The responsibilities are deliberately separated:

-   **Qwen** generates and repairs PHP source code.
-   **CTGAN** generates synthetic structured test data.

CTGAN is not used as a replacement for the LLM.

------------------------------------------------------------------------

## 18. Hybrid AI Architecture

PHP VibeCoder AI is a **hybrid system**, not a purely rule-based system.

  Component               Approach
  ----------------------- ----------------------------
  PHP code generation     Generative AI
  Debug code generation   Generative AI
  RAG                     Semantic retrieval
  LoRA                    ML fine-tuning
  CTGAN                   Generative ML
  PHP syntax validation   Deterministic
  Functional tests        Rule-based / deterministic
  Retesting               Deterministic
  Delivery decision       Rule-based

This separation is intentional:

> **Rules detect and verify the problem; AI generates the solution.**

Deterministic testing provides predictable validation around
probabilistic AI generation.

------------------------------------------------------------------------

## 19. Docker Containerization

Docker was explored as a deployment and portability mechanism for the
model API.

The inference service was successfully packaged into a Docker image and
pushed to a container registry.

Docker provides:

-   dependency isolation,
-   reproducibility,
-   portability,
-   a path toward persistent deployment.

For the final zero-cost prototype demonstration, live model inference
uses:

`Kaggle GPU → FastAPI → ngrok → Streamlit`

rather than a persistent paid cloud inference endpoint.

Docker therefore represents a deployment/containerization experiment and
future deployment path, rather than the primary AI component.

------------------------------------------------------------------------

## 20. Project Structure

A representative project structure is:

``` text
PHP_vibecoder_AI/
│
├── README.md
├── requirements.txt
├── .gitignore
│
├── streamlit_app/
│   ├── app.py
│   ├── .env                 # local only; not committed
│   └── services/
│       ├── generation_service.py
│       ├── php_service.py
│       └── rag_service.py
│
├── knowledge_base/
│   ├── php/
│   ├── mysql/
│   ├── codeigniter/
│   └── coding_standards/
│
├── chroma_db/               # local vector DB if generated locally
│
└── ci_app/
    ├── generated_projects/
    │   └── test.php         # generated at runtime
    └── tools/
        └── php_runner.py
```

Some generated/local-only files may be excluded from Git using
`.gitignore`.

------------------------------------------------------------------------

## 21. Installation and Setup

### Prerequisites

Install:

-   Python
-   PHP 8.x
-   Git
-   required Python packages from `requirements.txt`

Docker is optional for the local demonstration unless testing the
containerized deployment path.

### Clone the Repository

``` bash
git clone https://github.com/student1111111/PHP-VibeCoder-AI.git
cd PHP-VibeCoder-AI
```

### Create a Python Virtual Environment

Windows PowerShell:

``` powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### Install Dependencies

``` powershell
python -m pip install -r requirements.txt
```

### Verify PHP

``` powershell
php --version
```

### Configure the Model API

Create:

``` text
streamlit_app/.env
```

and add the active inference URL:

``` env
MODEL_API_URL=https://your-current-ngrok-url
```

Do not commit this file.

### Verify Model Backend

Before launching the frontend, verify the Kaggle FastAPI backend is
running and that its `/health` endpoint returns a successful response.

------------------------------------------------------------------------

## 22. Running the Application

From the project environment, start the Streamlit frontend using the
path appropriate for your project:

``` powershell
streamlit run streamlit_app/app.py
```

The application opens in the browser.

Enter a PHP development requirement and select **Generate & Test**.

The frontend will communicate with the active FastAPI model service.

------------------------------------------------------------------------

## 23. Example Demonstration

### Example Requirement

``` text
Create a secure customer registration system with login,
MySQL database and admin dashboard.
```

The current proof-of-concept focuses its automated validation primarily
on secure customer-registration behavior.

### Normal Workflow

``` text
Requirement received
        ↓
RAG context retrieved
        ↓
PHP generated by Qwen
        ↓
Generated PHP saved
        ↓
Syntax PASS
        ↓
Runtime PASS
        ↓
Functional tests PASS
        ↓
CTGAN synthetic tests PASS
        ↓
CODE READY FOR DELIVERY
```

### Debug Workflow

Enable the controlled password-security failure.

``` text
Secure PHP generated
        ↓
Controlled defect injected
        ↓
Functional tests FAIL
        ↓
Debug Agent receives failure
        ↓
Corrected PHP generated
        ↓
Correction saved
        ↓
Automatic retest
        ↓
Tests PASS
        ↓
CODE READY FOR DELIVERY
```

------------------------------------------------------------------------

## 24. Security Practices

The prototype demonstrates several secure development practices:

-   `password_hash()` for password storage,
-   `password_verify()` for password verification,
-   PDO prepared statements,
-   email validation,
-   no intended plain-text password storage,
-   security-oriented functional tests,
-   `.env` excluded from Git,
-   API credentials excluded from the repository,
-   automatic validation after AI correction.

### Plain Text vs. Hash

Insecure:

``` php
$hashedPassword = $password;
```

Secure:

``` php
$hashedPassword = password_hash(
    $password,
    PASSWORD_DEFAULT
);
```

During authentication:

``` php
password_verify($password, $storedHash);
```

------------------------------------------------------------------------

## 25. Results

The working proof-of-concept demonstrated:

-   natural-language requirement input,
-   RAG retrieval from the custom knowledge base,
-   PHP generation through the Qwen model,
-   saving generated PHP to disk,
-   PHP syntax validation,
-   real runtime execution,
-   functional registration tests,
-   password-security validation,
-   CTGAN synthetic testing,
-   automatic failure detection,
-   Qwen-based code repair,
-   automatic retesting,
-   final delivery status.

A successful synthetic test run demonstrated:

``` text
Total synthetic records: 20
Passed: 20
Failed: 0
```

The controlled security-failure demonstration also successfully showed
the full:

`Detect → Debug → Correct → Retest → Pass`

cycle.

------------------------------------------------------------------------

## 26. Limitations

This project is a **proof-of-concept**, not a production-ready
autonomous software-engineering platform.

Current limitations include:

-   the automated demonstration focuses mainly on customer-registration
    behavior,
-   a broad user prompt does not yet guarantee generation of every
    requested application module,
-   the complete production login/admin-dashboard workflow is outside
    the current validated scope,
-   Kaggle and free ngrok sessions are temporary,
-   synthetic testing covers a limited domain,
-   the fine-tuning dataset is relatively small,
-   generated code must still be validated before production use,
-   the system does not autonomously deploy a complete production
    application.

------------------------------------------------------------------------

## 27. Future Improvements

Potential extensions include:

-   new LLM MODEL for broader security testing,
-   complete multi-file CodeIgniter project generation,
-   login and authentication modules,
-   admin-dashboard generation,
-   database schema generation,
-   automated unit-test generation,
-   static code analysis,
-   larger CTGAN datasets,
-   additional edge-case testing,
-   persistent cloud GPU inference,
-   production Docker deployment,
-   CI/CD integration,
-   human approval gates before deployment.

------------------------------------------------------------------------

## 28. Project Contribution

The main contribution is the integration of multiple AI and
software-engineering stages into a single prototype.

The project demonstrates:

1.  task adaptation of a pretrained coding LLM using LoRA,
2.  domain knowledge retrieval through RAG,
3.  PHP code generation,
4.  execution in a real PHP runtime,
5.  deterministic automated validation,
6.  CTGAN synthetic-data testing,
7.  AI-assisted repair based on actual failures,
8.  automatic retesting before delivery.

The central idea can be summarized as:

> **AI generates and repairs the code; retrieval supplies relevant
> knowledge; deterministic tests verify the result; synthetic data
> broadens testing.**

------------------------------------------------------------------------

## 29. Conclusion

PHP VibeCoder AI demonstrates how Generative AI can be integrated with
traditional software-engineering validation.

Instead of stopping after code generation, the prototype executes the
generated program, evaluates it, detects failures, asks an AI Debug
Agent to repair them, and validates the correction again.

The final workflow is:

**Requirement → RAG → Qwen Generation → PHP Execution → Testing → AI
Debugging → Retesting → CTGAN Validation → Delivery**

The project therefore demonstrates a practical direction for building
more reliable AI-assisted coding systems while clearly separating
probabilistic AI generation from deterministic software validation.

------------------------------------------------------------------------

## Repository

GitHub repository:

`https://github.com/student1111111/PHP-VibeCoder-AI`

------------------------------------------------------------------------

## Disclaimer

This repository is proof-of-concept. AI-generated code
should be reviewed, tested, and security-audited before use in
production systems.
