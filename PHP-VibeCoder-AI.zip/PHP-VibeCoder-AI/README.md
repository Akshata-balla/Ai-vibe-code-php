## System Architecture

```mermaid
flowchart TD

    A["👤 User"] --> B["💻 Streamlit UI"]
    B --> C["📝 Requirement Input"]

    C --> D["🔍 RAG Retrieval<br/>ChromaDB"]

    D --> E["Fine-Tuned Qwen2.5-Coder<br/>+ PHP LoRA"]

    E --> F["⚙️ PHP Code Generator"]

    F --> G["💾 Save Generated PHP"]

    G --> H["🧪 Automated Testing"]

    H --> I{"Tests Passed?"}

    I -->|YES| J["CTGAN Synthetic Testing"]

    I -->|NO| K["🐛 AI Debug Agent"]

    K --> L["🔧 Generate Corrected PHP"]

    L --> M["💾 Save Corrected PHP"]

    M --> N["🔄 Automatic Retesting"]

    N --> O{"Retest Passed?"}

    O -->|YES| J

    O -->|NO| K

    J --> P{"CTGAN Tests Passed?"}

    P -->|YES| Q["🚀 CODE READY FOR DELIVERY"]

    P -->|NO| K
```