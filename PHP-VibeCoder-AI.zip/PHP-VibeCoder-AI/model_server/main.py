import torch
from fastapi import FastAPI
from pydantic import BaseModel
from transformers import AutoModelForCausalLM, AutoTokenizer


MODEL_PATH = "/repository"

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

dtype = (
    torch.float16
    if torch.cuda.is_available()
    else torch.float32
)


print("Loading PHP VibeCoder model...")

tokenizer = AutoTokenizer.from_pretrained(
    MODEL_PATH,
    trust_remote_code=True
)

model = AutoModelForCausalLM.from_pretrained(
    MODEL_PATH,
    dtype=dtype,
    device_map="auto",
    trust_remote_code=True
)

model.eval()

print("PHP VibeCoder model loaded.")


app = FastAPI(
    title="PHP VibeCoder API",
    version="1.0"
)


class GenerateRequest(BaseModel):
    user_request: str
    rag_context: str = ""


class DebugRequest(BaseModel):
    php_code: str
    failures: list[str]
    rag_context: str = ""


def run_model(
    system_prompt: str,
    user_prompt: str
) -> str:

    messages = [
        {
            "role": "system",
            "content": system_prompt
        },
        {
            "role": "user",
            "content": user_prompt
        }
    ]

    text = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )

    inputs = tokenizer(
        text,
        return_tensors="pt"
    ).to(model.device)

    with torch.no_grad():

        outputs = model.generate(
            **inputs,
            max_new_tokens=2048,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id
        )

    generated_tokens = outputs[0][
        inputs["input_ids"].shape[1]:
    ]

    return tokenizer.decode(
        generated_tokens,
        skip_special_tokens=True
    ).strip()


@app.get("/health")
def health():

    return {
        "status": "ok",
        "model": "PHP VibeCoder Qwen"
    }


@app.post("/generate")
def generate(
    request: GenerateRequest
):

    system_prompt = """
You are PHP VibeCoder AI.

You are an expert in:
- PHP 8.x
- CodeIgniter 4
- MySQL
- Authentication
- Validation
- Secure web development

Generate secure, clean and syntactically correct PHP code.

Use the supplied RAG knowledge when relevant.

Return only PHP code.
""".strip()

    user_prompt = f"""
RAG KNOWLEDGE:

{request.rag_context}

USER REQUIREMENT:

{request.user_request}

Generate the PHP solution.
""".strip()

    code = run_model(
        system_prompt,
        user_prompt
    )

    return {
        "success": True,
        "code": code
    }


@app.post("/debug")
def debug(
    request: DebugRequest
):

    failures = "\n".join(
        f"- {failure}"
        for failure in request.failures
    )

    system_prompt = """
You are PHP VibeCoder Debug Agent.

Analyze PHP code that failed automated testing.

Requirements:
- identify the actual cause
- preserve functionality that already works
- follow secure PHP 8.x practices
- use supplied RAG knowledge when relevant
- return only corrected PHP code
""".strip()

    user_prompt = f"""
RAG KNOWLEDGE:

{request.rag_context}

FAILED TESTS:

{failures}

CURRENT PHP CODE:

{request.php_code}

Correct the PHP code.
""".strip()

    code = run_model(
        system_prompt,
        user_prompt
    )

    return {
        "success": True,
        "code": code
    }