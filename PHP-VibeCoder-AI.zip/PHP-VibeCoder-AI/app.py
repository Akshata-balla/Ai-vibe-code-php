import re
import traceback

import streamlit as st

from services.php_service import (
    run_php_pipeline,
    save_generated_php,
)
from services.rag_service import retrieve_knowledge
from services.generation_service import (
    generate_php,
    debug_php,
)


# ---------------------------------------------------------
# PAGE CONFIGURATION
# ---------------------------------------------------------

st.set_page_config(
    page_title="PHP VibeCoder AI",
    page_icon="💻",
    layout="wide",
)


# ---------------------------------------------------------
# HEADER
# ---------------------------------------------------------

st.title("💻 PHP VibeCoder AI")

st.caption(
    "RAG + Fine-Tuned Qwen + PHP Runtime + Automated Testing + CTGAN"
)

st.divider()


# ---------------------------------------------------------
# USER REQUEST
# ---------------------------------------------------------

st.subheader("🧠 Application Requirement")

user_request = st.text_area(
    "Describe the PHP application you want to create:",
    placeholder=(
        "Create a secure customer registration system "
        "with login, MySQL database and admin dashboard."
    ),
    height=140,
)


# ---------------------------------------------------------
# CONTROLLED DEBUG DEMO OPTION
# ---------------------------------------------------------

demo_failure = st.checkbox(
    "🧪 Trigger controlled password-security failure",
    value=False,
    help=(
        "For demonstration only. This intentionally replaces "
        "password_hash() with plain-text password storage so "
        "the Debug Agent can detect, fix and retest the code."
    ),
)

test_mode_label = st.selectbox(
    "Test mode",
    [
        "Auto-detect",
        "Registration (full tests + CTGAN)",
        "Generic (syntax + execution)",
    ],
    help=(
        "Registration prompts get functional and CTGAN tests. "
        "Any other prompt is checked for syntax and CLI execution."
    ),
)

generate_button = st.button(
    "🚀 Generate & Test Application",
    type="primary",
    use_container_width=True,
)


# =========================================================
# WORKFLOW (computation only - results are stored in
# st.session_state so they survive Streamlit reruns, e.g.
# when the Download button is clicked)
# =========================================================

def clean_php(code: str) -> str:
    """
    Model output se sirf PHP code nikalta hai.
    Markdown fences (```php ... ```) aur uske aage-peeche ka
    explanation text hata deta hai, warna PHP me syntax error aata hai.
    """

    if not code:
        return code

    # 1. Closed fenced block: ```php ... ```
    match = re.search(
        r"```(?:php)?[ \t]*\r?\n(.*?)```",
        code,
        re.DOTALL | re.IGNORECASE,
    )

    if match:
        code = match.group(1)

    # 2. Fence open hai par close nahi hua
    elif "```" in code:
        code = re.sub(
            r"^.*?```(?:php)?[ \t]*\r?\n",
            "",
            code,
            count=1,
            flags=re.DOTALL | re.IGNORECASE,
        )
        code = code.split("```")[0]

    # 3. <?php se pehle ka koi bhi text hatao
    start = code.find("<?php")

    if start > 0:
        code = code[start:]

    # 4. Composer autoload line hatao (test folder me vendor/ nahi hai)
    code = re.sub(
        r"^[ \t]*(?:require|require_once|include|include_once)"
        r"[ \t]*\(?[ \t]*['\"][^'\"]*vendor/autoload\.php['\"][ \t]*\)?"
        r"[ \t]*;[ \t]*\r?\n?",
        "",
        code,
        flags=re.MULTILINE | re.IGNORECASE,
    )

    return code.strip() + "\n"


# Debug Agent kitni baar code fix karke retest karega
MAX_DEBUG_ATTEMPTS = 3

# Model ko ye rules har baar diye jayenge taaki code standalone chale
REGISTRATION_RULES = (
    "\n\nSTRICT RULES FOR THE OUTPUT (the automated tests depend on them):\n"
    "- Return ONLY raw PHP code starting with <?php. No explanation, "
    "no markdown fences, and no closing ?> tag.\n"
    "- Single standalone file. Do NOT use Composer, vendor/autoload.php, "
    "namespaces, 'use' imports, frameworks, models or any external "
    "library.\n"
    "- The file must ONLY define functions. It must NOT run anything at "
    "top level: no $_POST / $_GET / $_SESSION / $_SERVER access, no "
    "echo, no exit/die, no require/include, no new PDO connection.\n"
    "- It must define exactly this function:\n"
    "  function registerCustomer(PDO $pdo, string $name, "
    "string $email, string $password): bool\n"
    "- The database is a PDO connection passed in as $pdo (SQLite in "
    "tests, MySQL in production), so use only portable SQL with "
    "prepared statements and positional ? placeholders. "
    "Never use mysqli or bind_param.\n"
    "- Table name is 'customers' with columns: id, name, email "
    "(UNIQUE), password_hash. Insert into: name, email, password_hash.\n"
    "- Hash the password with exactly this expression: "
    "password_hash($password, PASSWORD_DEFAULT)\n"
    "- Validate input first: name length >= 3, valid email "
    "(filter_var FILTER_VALIDATE_EMAIL), password length >= 8. "
    "On invalid input, or if the email already exists, return false.\n"
    "- Return true only when the row was inserted successfully. "
    "Catch PDOException and return false.\n"
    "- The function is called 20+ times on the SAME $pdo, so it must be "
    "stateless: do NOT run CREATE TABLE, do NOT call beginTransaction / "
    "commit, do NOT change PDO attributes and do NOT keep static state.\n"
)


GENERIC_RULES = (
    "\n\nSTRICT RULES FOR THE OUTPUT:\n"
    "- Return ONLY raw PHP code starting with <?php. No explanation, "
    "no markdown fences.\n"
    "- Single standalone file. Do NOT use Composer, "
    "vendor/autoload.php, namespaces, 'use' imports, frameworks or any "
    "external library.\n"
    "- The file is executed from the command line (php file.php) and "
    "must finish without errors, warnings or exceptions.\n"
    "- Put the logic inside functions or classes. Never open a MySQL "
    "connection at top level; if a database is needed, accept a PDO "
    "object as a parameter or use SQLite in-memory inside a function.\n"
    "- Guard every $_POST / $_GET / $_SESSION / $_SERVER access with "
    "isset() or ??, and do not call exit/die at top level.\n"
    "- Use prepared statements for every query and password_hash("
    "$password, PASSWORD_DEFAULT) for passwords.\n"
    "- Security: validate and sanitize all input, escape any HTML output "
    "with htmlspecialchars(), and never trust user input.\n"
    "- Keep it compact (under ~150 lines): a few small functions or one "
    "small class, with portable SQL on a PDO object passed in.\n"
    "- At the very bottom add a short self-demo that runs ONLY when "
    "PHP_SAPI === 'cli': create an in-memory SQLite PDO "
    "(new PDO('sqlite::memory:') with ERRMODE_EXCEPTION), create the "
    "tables there, call the main functions once with sample data, and "
    "echo the results. It must end without any error.\n"
)


def detect_mode(text: str) -> str:
    """Prompt registration jaisa hai to full tests, warna generic."""

    if re.search(r"regist|sign.?up|customer", text, re.IGNORECASE):
        return "registration"

    return "generic"


def extract_failures(output: str, limit: int = 15) -> list:
    """
    Pipeline output se sirf kaam ki failure lines nikalta hai
    (PHP Deprecated wali repeat lines Debug Agent ko nahi jaati).
    """

    keys = (
        "FAIL:",
        "TEST ERROR:",
        "GAN TEST ERROR:",
        "Fatal error",
        "PHP Fatal error",
        "Parse error",
        "Warning:",
        "PHP Warning",
        "Passed:",
        "Failed:",
        "Total tests:",
    )

    lines = []

    for line in output.splitlines():
        text = line.strip()

        if "Deprecated" in text:
            continue

        if any(key in text for key in keys) and text not in lines:
            lines.append(text)

    if not lines:
        lines = [output[-1500:]]

    return lines[:limit]


def run_workflow(
    user_request: str,
    demo_failure: bool,
    mode: str,
) -> dict:

    rules = (
        REGISTRATION_RULES
        if mode == "registration"
        else GENERIC_RULES
    )

    run = {
        "user_request": user_request,
        "mode": mode,
        "demo_failure": demo_failure,
        "rag_results": [],
        "rag_error": None,
        "generated_php": None,       # code that was actually tested first
        "saved_file": None,
        "gen_error": None,
        "injection": None,           # None | "not_found" | "injected"
        "first_result": None,
        "debug": None,               # dict if debug agent ran
        "final_php": None,
        "final_result": {
            "success": False,
            "returncode": -1,
            "output": "",
        },
    }

    # -----------------------------------------------------
    # RAG RETRIEVAL
    # -----------------------------------------------------

    try:
        with st.spinner(
            "Searching PHP, CodeIgniter and MySQL knowledge..."
        ):
            run["rag_results"] = retrieve_knowledge(
                user_request,
                top_k=2,
            ) or []
    except Exception:
        run["rag_error"] = traceback.format_exc()

    rag_context = "\n\n".join(
        item["document"] for item in run["rag_results"]
    )

    # -----------------------------------------------------
    # PHP GENERATION
    # -----------------------------------------------------

    generated_php = None

    try:
        with st.spinner(
            "Generating PHP with fine-tuned Qwen..."
        ):
            generated_php = clean_php(
                generate_php(
                    user_request + rules,
                    rag_context,
                )
            )

        if generated_php:

            run["saved_file"] = save_generated_php(generated_php)

            # Controlled failure injection (demo only)
            if demo_failure:

                broken_php = generated_php.replace(
                    "password_hash($password, PASSWORD_DEFAULT)",
                    "$password",
                )

                if broken_php == generated_php:
                    run["injection"] = "not_found"
                else:
                    generated_php = broken_php
                    save_generated_php(generated_php)
                    run["injection"] = "injected"

    except Exception:
        run["gen_error"] = traceback.format_exc()
        generated_php = None

    run["generated_php"] = generated_php
    run["final_php"] = generated_php

    # -----------------------------------------------------
    # TESTING + DEBUG LOOP
    # -----------------------------------------------------

    if generated_php:

        with st.spinner(
            "Running syntax, execution, functional "
            "and CTGAN tests..."
        ):
            result = run_php_pipeline(mode)

        run["first_result"] = result
        run["final_result"] = result

        if not result["success"]:

            debug = {
                "attempts": [],
                "error": None,
            }

            current_php = generated_php
            current_output = result["output"]

            try:
                for attempt in range(1, MAX_DEBUG_ATTEMPTS + 1):

                    with st.spinner(
                        f"Debug attempt {attempt}/{MAX_DEBUG_ATTEMPTS}: "
                        "analyzing failure with RAG + fine-tuned Qwen..."
                    ):
                        corrected_php = clean_php(
                            debug_php(
                                current_php,
                                extract_failures(current_output),
                                rag_context + rules,
                            )
                        )

                    corrected_file = save_generated_php(corrected_php)

                    with st.spinner(
                        "Running automated tests again..."
                    ):
                        retry_result = run_php_pipeline(mode)

                    debug["attempts"].append(
                        {
                            "corrected_php": corrected_php,
                            "corrected_file": corrected_file,
                            "retry_result": retry_result,
                        }
                    )

                    # Final code = latest corrected code
                    run["final_php"] = corrected_php
                    run["final_result"] = retry_result

                    if retry_result["success"]:
                        break

                    # Agli attempt latest code + latest error se hogi
                    current_php = corrected_php
                    current_output = retry_result["output"]

            except Exception:
                debug["error"] = traceback.format_exc()

            run["debug"] = debug

    return run


# =========================================================
# RENDERING (always reads from the stored run dict)
# =========================================================

def render_run(run: dict) -> None:

    # -----------------------------------------------------
    # 1. REQUIREMENT ANALYSIS
    # -----------------------------------------------------

    st.subheader("1️⃣ Requirement Analysis")
    st.write("User Request:")
    st.info(run["user_request"])
    st.caption(f"Test mode: {run['mode']}")

    # -----------------------------------------------------
    # 2. RAG KNOWLEDGE RETRIEVAL
    # -----------------------------------------------------

    st.subheader("2️⃣ RAG Knowledge Retrieval")

    if run["rag_error"]:
        st.error("RAG retrieval failed.")
        st.code(run["rag_error"], language="text")

    elif run["rag_results"]:
        st.success(
            f"Retrieved {len(run['rag_results'])} "
            "relevant knowledge sources."
        )

        for index, item in enumerate(run["rag_results"], start=1):
            with st.expander(f"Source {index}: {item['source']}"):
                st.write(
                    "Similarity distance:",
                    round(float(item["distance"]), 4),
                )
                st.code(item["document"], language="text")

    else:
        st.warning("No RAG knowledge was retrieved.")

    # -----------------------------------------------------
    # 3. PHP CODE GENERATION
    # -----------------------------------------------------

    st.subheader("3️⃣ PHP Code Generation")

    if run["gen_error"]:
        st.error("PHP generation failed.")
        st.code(run["gen_error"], language="text")

    elif run["generated_php"]:
        st.success("PHP code generated successfully.")

        if run["saved_file"]:
            st.info(
                f"Generated code saved to: {run['saved_file']}"
            )

        if run["demo_failure"]:

            st.subheader("🧪 Controlled Failure Injection")

            if run["injection"] == "not_found":
                st.warning(
                    "Controlled failure could not be injected "
                    "because the expected password_hash() pattern "
                    "was not found."
                )

            elif run["injection"] == "injected":
                st.warning(
                    "Controlled password-security failure injected."
                )
                st.write(
                    "The secure password hashing statement was "
                    "temporarily replaced with plain-text storage "
                    "for the Debug Agent demonstration."
                )

        st.caption("Code used for testing:")
        st.code(run["generated_php"], language="php")

    else:
        st.warning("The model returned empty PHP code.")

    # -----------------------------------------------------
    # 4. AUTOMATED TESTING + DEBUG LOOP
    # -----------------------------------------------------

    st.subheader("4️⃣ Automated Testing")

    if not run["generated_php"]:
        st.warning(
            "Testing skipped because PHP "
            "generation did not complete."
        )

    else:
        first = run["first_result"]

        if first["success"]:
            st.success(
                "✅ PHP VibeCoder pipeline "
                "completed successfully."
            )
            st.code(first["output"], language="text")

        else:
            st.error("❌ Generated PHP failed automated testing.")
            st.code(first["output"], language="text")

            st.subheader("🐛 Automatic Debug Agent")

            debug = run["debug"]

            if debug is None or (
                debug["error"] and not debug["attempts"]
            ):
                st.error("Automatic debugging failed.")
                if debug and debug["error"]:
                    st.code(debug["error"], language="text")

            else:
                total = len(debug["attempts"])

                for number, attempt in enumerate(
                    debug["attempts"], start=1
                ):
                    st.success(
                        f"Debug Agent correction {number}/{total} generated."
                    )
                    st.code(attempt["corrected_php"], language="php")

                    st.info(
                        f"Corrected PHP saved to: "
                        f"{attempt['corrected_file']}"
                    )

                    st.subheader(
                        f"🔄 Retesting Corrected Code (attempt {number})"
                    )

                    retry = attempt["retry_result"]
                    st.code(retry["output"], language="text")

                    if retry["success"]:
                        st.success(
                            "✅ Debug successful. "
                            "Corrected code passed all tests."
                        )

                if debug["error"]:
                    st.error("Automatic debugging stopped with an error.")
                    st.code(debug["error"], language="text")

    # -----------------------------------------------------
    # 5. DELIVERY
    # -----------------------------------------------------

    st.subheader("5️⃣ Delivery")

    final_result = run["final_result"]
    final_php = run["final_php"]

    ready = (
        final_result["success"]
        and "CODE READY FOR DELIVERY" in final_result["output"]
    )

    if ready:

        st.success("🚀 CODE READY FOR DELIVERY")

        if run["demo_failure"] and run["debug"]:
            st.info(
                "Controlled failure demo completed: "
                "the system detected the security defect, "
                "generated corrected PHP and passed the retest."
            )

        if final_php:
            st.download_button(
                label="⬇️ Download PHP Code",
                data=final_php,
                file_name="generated_app.php",
                mime="application/x-httpd-php",
                use_container_width=True,
                key="download_php_ready",
            )

    else:

        # Failed hone par bhi review ke liye download
        # (sirf verified code chahiye to ye block hata do)
        if final_php:
            st.download_button(
                label="⬇️ Download PHP Code",
                data=final_php,
                file_name="generated_app_verified.php",
                mime="application/x-httpd-php",
                use_container_width=True,
                key="download_php_verified",
            )


# =========================================================
# MAIN
# =========================================================

if generate_button:

    if not user_request.strip():
        st.warning("Please enter an application requirement.")

    else:
        st.success("Requirement received successfully.")

        st.session_state["user_request"] = user_request

        if test_mode_label.startswith("Registration"):
            mode = "registration"
        elif test_mode_label.startswith("Generic"):
            mode = "generic"
        else:
            mode = detect_mode(user_request)

        st.session_state["run"] = run_workflow(
            user_request,
            demo_failure,
            mode,
        )

        st.session_state["generated_php"] = (
            st.session_state["run"]["final_php"]
        )


# Download click ke baad bhi result page yahin bana rahega
if "run" in st.session_state:
    render_run(st.session_state["run"])